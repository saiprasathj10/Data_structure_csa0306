INTELLITYPE X - PROFESSIONAL C / DSA EDITION
============================================

WHAT IS INCLUDED
- intellitype_x.c: complete C11 DSA implementation
- run_intellitype_x.bat: one-click Windows build and launch
- README_IntelliType_X.txt: this guide

REQUIREMENTS
- Windows 10/11
- GCC installed and available in PATH
  Recommended: MSYS2 UCRT64 GCC

EASIEST WAY TO RUN
1. Extract the ZIP into a normal folder (for example Desktop\IntelliTypeX).
2. Double-click run_intellitype_x.bat.
3. The script compiles the C source and launches the program.
4. The local profile is saved in intellitype_profile.dat in the same folder.

MANUAL BUILD
Open CMD in this folder and run:
  gcc -std=c11 -O2 -Wall -Wextra intellitype_x.c -o IntelliTypeX.exe
  IntelliTypeX.exe

FEATURES IMPLEMENTED IN C
1. Trie insertion and prefix lookup
2. DFS candidate collection
3. Bounded Top-5 ranking
4. Weighted frequency / recency / category scoring
5. Levenshtein typo recovery
6. Local persistence for selection counts and recency
7. Search history for the current session
8. Category distribution analytics
9. Trie-vs-linear prefix benchmark
10. Dynamic memory cleanup

DEMO SCRIPT
A. Select 1 (Search), choose 1 (AIML), enter: deep
B. Search again with category 0 and prefix: mach
C. Test typo recovery: machne
D. Select a result to update the personal ranking profile.
E. Repeat the same search and observe the score / order.
F. Select 3 for analytics.
G. Select 4 and benchmark prefix: mach.
H. Select 5 to show implemented capabilities and limitations.

DSA EXPLANATION
- Trie: each edge represents one character; shared prefixes share paths.
- Prefix lookup: O(P), where P is the prefix length.
- DFS: explores only the subtree under the matching prefix node.
- Top-K: keeps at most five best candidates during traversal.
- Levenshtein: dynamic programming for insertion, deletion and substitution.
- Linear benchmark: scans all dictionary entries for comparison.

SCORING FORMULA
Score = 0.55 * frequency + 0.25 * recency + 0.20 * context - typo penalty
Frequency includes a capped personal selection boost. Recency uses a logical clock.

IMPORTANT HONESTY NOTES
- This is an offline, rule-based search engine, not a trained AI model.
- The included dictionary is a curated demonstration dataset, not millions of words.
- Search history is session-only; selection profile persists in intellitype_profile.dat.
- Benchmark timings on a small dataset are illustrative, not proof of production-scale speed.
