@echo off
cd /d "%~dp0"
title IntelliType X - Offline Search Intelligence
where gcc >nul 2>nul
if errorlevel 1 (
  echo GCC was not found. Install MSYS2 UCRT64 GCC and add C:\msys64\ucrt64\bin to PATH.
  pause
  exit /b 1
)
echo Building IntelliType X...
gcc -std=c11 -O2 -Wall -Wextra intellitype_x.c -o IntelliTypeX.exe
if errorlevel 1 (
  echo Build failed. Check the compiler messages above.
  pause
  exit /b 1
)
echo.
echo Build successful. Starting IntelliType X...
IntelliTypeX.exe
pause
