INTELLITYPE X — WEB EDITION
============================

This is a browser-based interface powered by a C11 search engine compiled to WebAssembly.

RUN:
1. Extract the ZIP.
2. Double-click index.html (Chrome or Edge recommended).
3. Start typing in the search field.
4. Select a result to update the C engine's frequency/recency ranking.
5. Use the sidebar: Smart Search, Trie Explorer, Analytics, Benchmark.

IMPORTANT:
- Prefix lookup, candidate collection, ranking and edit-distance recovery are implemented in C.
- intellitype_engine.wasm is compiled from intellitype_engine.c.
- index.html embeds the WASM binary, so no server, npm, Python or extra installation is needed.
- All data runs locally in the browser. No network requests are made.
- The dictionary is a curated 55-term classroom demonstration dataset, not a production-scale index.
- The Trie Explorer is a conceptual visualization of the prefix path; it is not a live memory inspector.
- The benchmark compares browser workload timings and should not be presented as proof of large-scale superiority.

FILES:
index.html              Web interface (WASM embedded)
intellitype_engine.c    Actual C11 search engine source
intellitype_engine.wasm Compiled WebAssembly engine
README.txt              This guide

DSA TOPICS:
Trie insertion and prefix traversal, DFS candidate collection, bounded top-K ranking,
frequency/recency/context score, Levenshtein edit distance, WebAssembly integration.
